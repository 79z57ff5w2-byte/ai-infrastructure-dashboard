
# AI Infrastructure Intelligence Dashboard

A lightweight MVP app for tracking the AI infrastructure value chain, ETF exposure, and AI capex signals.

## What it includes

1. **Infrastructure Tracker**
   - Tracks key AI infrastructure companies across semiconductors, data centers, energy, networking, and cooling.

2. **ETF Exposure Analyzer**
   - Compares ETF exposure to different parts of the AI value chain.

3. **AI Capex Monitor**
   - Tracks major AI-related spending signals and maps them to likely beneficiaries.

## How to run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install requirements:

```bash
pip install -r requirements.txt
```

4. Run the app:

```bash
streamlit run app.py
```

## Suggested next steps

- Replace sample data with live/manual holdings data.
- Add CSV upload support.
- Add a scoring model editor.
- Deploy to Streamlit Community Cloud.
- Later, connect to financial/news APIs.
